document.addEventListener('DOMContentLoaded', function () {
    // Generate team members' information
    const teamMembers = [
        { name: 'Johnathan Smith', role: 'Founder and Head Baker' },
        { name: 'Kerry David', role: 'Pastry Chef Extraordinaire' },
        { name: 'Michael John', role: 'Master Barista' }
    ];

    const teamMembersContainer = document.querySelector('#main-content .container');
    const teamList = document.createElement('ul');
    
    teamMembers.forEach(member => {
        const listItem = document.createElement('li');
        listItem.textContent = `${member.name} - ${member.role}`;
        teamList.appendChild(listItem);
    });

    const teamSectionTitle = document.createElement('p');
    teamSectionTitle.textContent = 'Meet our team:';
    teamSectionTitle.classList.add('team-title');

    teamMembersContainer.appendChild(teamSectionTitle);
    teamMembersContainer.appendChild(teamList);
});

    


